<?php
// Este archivo debe ser importado sólo por los archivos que NO están en el directorio raíz
$nombreDelSitio = "Infosegura";
$sloganDelSitio = "Rico slogan";
$emailAdm = "santiagogimenez@outlook.com.ar";
// Se deben importar todos los estados de los plug-ins
include_once("../plug-in/calendario/estado.php");
// Acá van los estilos CSS de los Plug-In
if($calendarioEstado){ ?>
<link rel="stylesheet" href="../plug-in/calendario/css/calendario.css" />
<?php }

//include_once("plug-in/calendario/estado.php"); // Se llama el archivo como si fuera desde index.php
/* Configuraciones para el usuario */
	/*if((isset($_COOKIE["emailCookie"])) && (isset($_COOKIE["contrasenaCookie"]))) {
	 		include_once("../usuario/".strip_tags(htmlspecialchars($_COOKIE["emailCookie"]))."/credenciales.php");
	 		include_once("../usuario/".strip_tags(htmlspecialchars($_COOKIE["emailCookie"]))."/opciones-de-perfil.php");
	 		include_once("../usuario/".strip_tags(htmlspecialchars($_COOKIE["emailCookie"]))."/configuracion.php");
	}*/
?>