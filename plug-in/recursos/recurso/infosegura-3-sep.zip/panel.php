<!doctype html>
<html lang="es">

 <head>
 	<?php include_once("sistema/informacion.php"); ?>
 	<title><?php echo $nombreDelSitio; ?> | Panel de control</title>
 	<link rel="stylesheet" href="css/panel.css" />
 	<meta charset="UTF-8" />
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 </head>
 
<body>
<?php
/* Importa las credenciales del usuario en caso de que se haya iniciado sesión, así el header puede determinar
	si crear otras listas específicas para los usuarios logueados o no */
if( (isset($_COOKIE["emailCookie"])) && (isset($_COOKIE["contrasenaCookie"])) ) {
	$rutaUsuario = "usuario/".strip_tags(htmlspecialchars($_COOKIE["emailCookie"]));
	include_once($rutaUsuario."/credenciales.php");
if( ($rol==0) || ($rol==1) ) { ?>
<div id="sidebar">

<ul>
	<?php if( ($rol==0) || ($rol==1) ) { ?>
	<li><a href="index.php">Inicio</a></li>
	<li><a href="#crearPost">Crear post</a></li>
	<li><a href="#misPosts">Mis Posts</a></li>
	<?php } if($rol==0) { ?>
	<li><a href="#usuarios">Usuarios</a></li>
	<li><a href="#plugins">Plugins</a></li>
	<li><a href="#configuracion">Configuración</a></li>
	<?php } ?>
</ul>

</div>
<?php
// Contador de usuarios
$carpetaDeUsuarios = "usuario";
$fi = new FilesystemIterator($carpetaDeUsuarios, FilesystemIterator::SKIP_DOTS);
$contadorDeUsuarios = iterator_count($fi);

// Contador de posts
$carpetaDePosts = "usuario/".strip_tags(htmlspecialchars($_COOKIE["emailCookie"]))."/backup";
$fi = new FilesystemIterator($carpetaDeUsuarios, FilesystemIterator::SKIP_DOTS);
$contadorDePosts = iterator_count($fi);
?>
<!-- Acá se colocan noticias sobre el CMS, un resúmen del sistema -->
<div id="contenedor">

<h1>Panel de control de <?php echo $nombreDelSitio; ?></h1>
<h5>Chiqui v0.3</h5>
	<div id="caja">
	 <div class="dash">
	 	<p>Tenés <a href="#misPosts"><?php echo $contadorDePosts; ?> post</a>.</p>
	 	<p>Te registraste el día <?php echo $diaDeRegistro; ?>.</p>
	 </div>
	</div>

	<div id="caja">
	 <div class="dash">
	 	<p>La web cuenta con <?php echo $contadorDeUsuarios; ?> usuarios.</p>
	 	<?php
	 		  if($rol==0) {
				echo '<p>Sos administrador.</p>';
				echo '<p><a href="#plugins">Administrar plugins</a>.</p>';
	 		} else if($rol==1) {
	 			echo '<p>Sos redactor.</p>';
	 		} else if($rol==2) {
	 			echo '<p>Sos un visitante del sitio.</p>';
	 		} else {}
	 	?>
	 	
	 	
	 </div>
	</div>
</div>

<!-- Acá arrancan todas las solapas. ¡Que comiencen los juegos del hambre! -->
<?php 
if( ($rol=0) || ($rol=1) ) { ?>
<div id="crearPost">
<div id="cerrar"><a href="#">X</a></div>
 <form action="sistema/crear-post.php" method="post" style="clear:both;">
	<input type="text" placeholder="Título del post" name="titulo" class="tituloInput" />
	 <div id="herramientas">
	  <ul>
	 	<li>N</li>
	 	<li>I</li>
	 	<li>S</li>
	 	<li>Énfasis</li>
	 	<li>Cuadro</li>
	  </ul>	
	 </div>
 	<textarea name="texto" placeholder="Insertá el contenido de tu post"></textarea>
 	<input type="text" name="portada" placeholder="Link de tu portada" /¿>
    <input type="submit" value="Crear post" />
 </form>
</div>

<div id="misPosts">
<div id="cerrar"><a href="#">X</a></div>
 <ul>
  <?php
  include_once($rutaUsuario."/mis-posts.php");
  ?>
 </ul>
</div>

<div id="usuarios">
	<div id="cerrar"><a href="#">X</a></div>
	<div id="accesoRapido">
		<h3>Crear un usuario</h3>
		<form action="sistema/agregar-usuario.php" method="post">
			<input type="text" placeholder="E-mail" name="email" />
			<input type="text" placeholder="Contraseña (visible)" name="contrasena" />
			<input type="submit" value="Agregar usuario" />
		</form>
	</div>
	<p>De momento, no hay opciones para borrar ni editar usuarios.</p>
</div>

<div id="plugins">
	<div id="cerrar"><a href="#">X</a></div>
	 <div class="left">
	 	<form action="plug-in/instalar-plugin.php" method="post">
		<input type="file" name="zip" />
		<input type="submit" value="Subir plugin" />
	 	</form>
	 </div>

	 <div class="right">
	 	<p style="clear: both;"><a href="http://cms.olivaires.com.ar">¿Cómo desarrollar un plugin para Chiqui CMS?</a></p>
	 </div>

		<div class="center"><h3>Plugins instalados</h3>
		<ul>
		 <?php include_once("plug-in/instalado/recursos.php"); ?>
		</ul></div>
</div>

<?php }
		} else {
			echo '<div id=¨contenido¨>No tenés permiso para acceder al panel de control.</div>';
		}
	}
	?>
</body>
</html>