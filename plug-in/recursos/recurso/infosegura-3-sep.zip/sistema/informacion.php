<?php
//
$nombreDelSitio = "Infosegura";
$sloganDelSitio = "Rico slogan";
$emailAdm = "santiagogimenez@outlook.com.ar";
// Se deben importar todos los estados de los plug-ins
include_once("plug-in/calendario/estado.php");
// Acá van los estilos CSS de los Plug-In
if($calendarioEstado){ ?>
<link rel="stylesheet" href="plug-in/calendario/css/calendario.css" />
<?php } ?>