<?php $emailUsuario="santiagogimenez99@gmail.com"; $contrasenaUsuario="test"; $diaDeRegistro="09.02.18"; $rol=0; /* 0: administrador | 1: autor | 2: visitante */ ?>
