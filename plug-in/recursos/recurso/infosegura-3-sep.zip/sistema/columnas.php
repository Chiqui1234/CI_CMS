 <div id="columnaIzq">
	<div class="titulo">Cuidémosnos</div>
	 <ul>
	 	<li><a href="http://www.cibercrimen.org.ar/?page_id=34">Asesoramiento legal</a></li>
	 	<li><a href="https://www.argentina.gob.ar/denunciar-un-delito-informatico">Denunciar cibercrimen</a></li>
	 	<li><a href="https://www.phishtank.com/">Verificar phishing</a></li>
	 	<li class="sosNoticia"><a href="sos-noticia.php" title="Si querés que expongamos tu caso para que los demás no cometan el
mismo error, sos bienvenido. Además, nos ocuparemos de denunciar tu caso">Sos noticia</a></li>
	 </ul>
 </div>
 
 <div id="columnaCen">
 	<div class="titulo">Eventos</div>
 	<?php include_once("plug-in/calendario/calendario-empotrable.php"); ?>
 	<p><a href="#agosto">Calendario completo acá</a></p>
 	<p>¿Nos querés contactar para presupuestar una charla? ¡<a href="#contacto">Contactanos</a>!</p>
 </div>
 
 <div id="columnaDer">
 	<div class="titulo">Mejores posts</div>
 	<ul>
 		<a href=""><li style="background-image:url('http://sorollaseguridad.es/wp-content/uploads/2015/02/CATT_Seguridad_1920x1274px-e1360665448439.jpg');">
 			<div class="tituloPost">Seguridad Corporativa: ¿la tenemos en cuenta?</div>
 		</li></a>
 		
 		<a href="https://www.infosegura.com.ar/blog/introducci%C3%B3n-al-qa-tester"><li style="background-image:url('https://static.wixstatic.com/media/25d1f48ff8564b40b8f70a56324b696f.jpg/v1/fit/w_740,h_494,al_c,q_90/file.jpg');">
 			<div class="tituloPost">Introducción al QA TESTER</div>
 		</li></a>
 		
 		<a href="https://www.infosegura.com.ar/blog/que-es-una-botnet-pc-zombie"><li style="background-image:url('https://i.blogs.es/52bf65/botnet-thriller/original.jpg');">
 		<div class="tituloPost">¿Qué es una botnet? ¿PC Zombie?</div>
 		</li></a>
 	</ul>
 </div>