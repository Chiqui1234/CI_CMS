<footer>
<div id="centro">
	<div id="columnaIzq">
		<h1>Socios</h1>
		<ul>
			<li><a href="#">Info Segura</a></li>
			<li><a href="#">Socio #2</a></li>
			<li><a href="#">Socio #3</a></li>
			<li><a href="#">Socio #4</a></li>
			<li><a href="#">Socio #5</a></li>
		</ul>
	</div>
	<div id="columnaDer">
		<h1>Miembros</h1>
	</div>
</div>
<div id="footerReal">Desarrollado y diseñado por Santiago A. Gimenez bajo la licencia general pública de GNU | 2018 | GitHub</div>
</footer>