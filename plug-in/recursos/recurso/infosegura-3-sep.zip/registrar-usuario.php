<?php include_once("sistema/informacion.php"); ?>
<!doctype html>
<html lang="es">

 <head>
 	<title><?php echo $nombreDelSitio; ?> | Registrar usuario</title>
 	<?php include_once("sistema/header-html.php"); ?> <!-- Para insertar estilos CSS -->
 	<meta charset="UTF-8" />
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 </head>
 
<body>
<div id="contenido" style="margin-top: 72px;">
 <?php
 include_once("sistema/header.php");
 	/* Escape de simbolos html y php, tanto de manera explicita
		como en alternativas. Ejemplo "&gt" es igual a ">"
	*/
	$emailSaneado = strip_tags(htmlspecialchars($_REQUEST["email"]));
	$contrasenaSaneada = strip_tags(htmlspecialchars($_REQUEST["contrasena"]));
	$contrasenaRepetidaSaneada = strip_tags(htmlspecialchars($_REQUEST["contrasenaRepetida"]));
	/* Se crea tu carpeta de usuario con las credenciales y archivos
	basicos de usuario, si las contraseñas son idénticas */
	$rutaUsuario = "usuario/".$emailSaneado; /* La ruta completa al usuario. Se le puede agregar "credenciales.php" 
												para referirse al archivo que almacena las credenciales del usuario.
												Tené en cuenta que el usuario tiene archivos de configuración extra,
												cómo opciones-de-perfil.php y configuracion.php */
	if($contrasenaSaneada === $contrasenaRepetidaSaneada) {
		
		if(!file_exists($rutaUsuario)){
			mkdir($rutaUsuario, 0777) OR DIE("No se pudo crear el usuario, contactate con la
				<a href=´".$emailAdm."´>administración</a>. <a href='javascript:history.back();'>Volver</a>");
			mkdir($rutaUsuario."/backup", 0777) OR DIE("No se pudo crear el usuario, contactate con la
				<a href=´".$emailAdm."´>administración</a>. <a href='javascript:history.back();'>Volver</a>");
			// Credenciales de usuario
			date_default_timezone_set("America/Argentina/Buenos_Aires"); // Pongo la zona en GMT-3 para Buenos Aires
			$diaDeRegistro = strip_tags(htmlspecialchars(date("m.d.y")));
			$credencialesOpen = fopen($rutaUsuario."/credenciales.php", "w");
			fwrite($credencialesOpen, '<?php $emailUsuario="'.$emailSaneado.'"; $contrasenaUsuario="'.$contrasenaSaneada.'"; $diaDeRegistro="'.$diaDeRegistro.'"; $rol=2; /* 0: administrador | 1: autor | 2: visitante */ ?>');
			fclose($credencialesOpen);
			// Opciones de perfil (avatar, portada, si es público o no, etc)
			$opcionesDePerfil = fopen($rutaUsuario."/opciones-de-perfil.php", "w");
			fwrite($opcionesDePerfil, '<?php $avatarUsuario="https://scontent.faep4-1.fna.fbcdn.net/v/t1.0-9/31351289_1778476068842197_8811803553015267328_n.jpg?_nc_cat=0&oh=01408922f19b269638b3aa996b57e965&oe=5C0A98AA"; $portadaUsuario="img/portada/space3.jpg";  $publicoUsuario=false; ?>');
			fclose($opcionesDePerfil);
			// Configuración (notificaciones en la APP (si existe), notificaciones vía email)
			$configuracionArchivo = fopen($rutaUsuario."/configuracion.php", "w");
			fwrite($configuracionArchivo, '<?php $notificacionesEnApp=false; $notificacionesViaEmail=false; ?>');
			fclose($configuracionArchivo);
			/* Se crea este archivo para indexar los posts del usuario, que por defecto (cuando no hay posts)
			imprime el mensaje "No tenés posts de tu autoria." */
			$misPostsArchivo = fopen($rutaUsuario."/mis-posts.php", "w");
			fwrite($misPostsArchivo, "<?php echo 'No tenés posts de tu autoría.'; ?>");
			fclose($misPostsArchivo);
			/* Creamos el token */
			/*$contrasenaTokenAEscribir = '<?php $contrasenaTokenUsuario=md5("'.$contrasenaSaneada.'"); ?>';
			$tokenRuta = fopen($rutaUsuario."/contrasena-token.php", "w");
 			fwrite($tokenRuta, $contrasenaTokenAEscribir);
 			fclose($tokenRuta);*/
			echo "¡Gracias por registrarte! Te enviaremos un email a ".$emailSaneado." con tus credenciales. <a href='ingresar.php'>Iniciar sesión</a>.";
		} else {
			echo "Este mail ya fue registrado, <a href='recuperar-contrasena.php'>¿perdiste tu contraseña?</a>.";
		}

	} else {
		echo "Las contraseñas no coinciden. <a href='javascript:history.back();'>Volver</a>.";
	}
	
 ?>
</div>
</body>
</html>