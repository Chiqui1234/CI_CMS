<header>
		<a href="#menuSlider" style="display: block;border:none;"><div id="menuIconPulsador"></div></a>
		<div class="menu icon"></div>
		<!-- MenuSlider -->
		<div id="menuSlider">
			<ul>
			 <li><a href="index.php">INICIO</a></li>
			 <li><a href="blog.php">BLOG</a></li>
			 <li><a href="recursos.php">RECURSOS</a></li>
			 <li><a href="index.php#contacto">CONTACTO</a></li>
			 <?php if((isset($_COOKIE["emailCookie"])) && (isset($_COOKIE["contrasenaCookie"]))) { ?>
			 <li><a href="perfil.php">PERFIL</a></li>
			 <?php } else { ?>
			 <li><a href="ingresar.php">INGRESAR</a></li>
			 <?php } if((isset($_COOKIE["emailCookie"])) && (isset($_COOKIE["contrasenaCookie"]))) {if($rol==0) { ?>
			 <li><a href="panel.php">PANEL</a>
			 <?php } if($rol==1) { ?>
			 <li><a href="panel.php#crearPost">REDACTAR</a></li>
			 <?php }} ?>
			</ul>
		</div>

	<a href="index.php" style="display: block;border:none;"><div class="logo"></div></a>
	<ul>
		<li><a href="index.php">INICIO</a></li>
		<li><a href="blog.php">BLOG</a></li>
		<li><a href="recursos.php">RECURSOS</a></li>
		<li><a href="index.php#contacto">CONTACTO</a></li>
		<?php if((isset($_COOKIE["emailCookie"])) && (isset($_COOKIE["contrasenaCookie"]))) { ?>
		<li><a href="perfil.php">PERFIL</a></li>
		<?php } else { ?>
		<li><a href="ingresar.php">INGRESAR</a></li>
		<?php } if((isset($_COOKIE["emailCookie"])) && (isset($_COOKIE["contrasenaCookie"]))) {if($rol==0) { ?>
		<li><a href="panel.php">PANEL</a>
		<?php } if($rol==1) { ?>
		<li><a href="panel.php#crearPost">REDACTAR</a></li>
		<?php }} ?>

	</ul>
</header>