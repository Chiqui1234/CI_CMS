<!-- Acá se listan todos los posts de los blogs, podrán crearse más archivos con el sufijo
"blog", seguido de un número. Por ejemplo, la primer página sería "1.php", mientras que
la segunda página sería "2.php", luego "3.php", etc. Se listan 10 posts por página. 
El CMS listará los posts más nuevos primero, es decir, si tenemos los archivos "1.php",
"2.php" y "3.php", el sistema interpretará al archivo "3.php" como el último
y lo mostrará primero. -->