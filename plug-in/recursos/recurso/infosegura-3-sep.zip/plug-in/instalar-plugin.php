<!doctype html>
<html lang="es">

 <head>
 	<?php include_once("../informacion-sub.php"); ?>
 	<title><?php echo $nombreDelSitio; ?></title>
 	<?php include_once("../sistema/header-html-sub.php"); ?> <!-- Para insertar estilos CSS -->
 	<meta charset="UTF-8" />
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 </head>
 
<body>
<!-- Acá hay info:
	https://stackoverflow.com/questions/22355653/upload-zip-file-and-extract-the-zip
 -->
</body>
</html>