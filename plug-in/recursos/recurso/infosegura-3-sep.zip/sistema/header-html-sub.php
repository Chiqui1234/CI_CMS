<!-- El estilo predeterminado -->
<link rel="stylesheet" href="../css/estilo.css" />
<link rel="shortcut icon" type="image/png" href="../img/favicon.png"/>
<!-- Barra espaciadora de bajo presupuesto -->
