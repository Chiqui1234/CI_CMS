<!doctype html>
<html lang="es">

 <head>
 	<?php include_once("sistema/informacion.php"); ?>
 	<title><?php echo $nombreDelSitio; ?></title>
 	<?php include_once("sistema/header-html.php"); ?> <!-- Para insertar estilos CSS -->
 	<meta charset="UTF-8" />
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 </head>
 
<body>
<?php
if( (isset($_COOKIE["emailCookie"])) && (isset($_COOKIE["contrasenaCookie"])) ) {
$rutaUsuario = "usuario/".strip_tags(htmlspecialchars($_COOKIE["emailCookie"]));
	include_once($rutaUsuario."/credenciales.php");
}
?>
<!--<script type="text/javascript" >
	alert('En construcción, ¡no adaptada a móviles! En la home (sin tener en cuenta que faltan muchas páginas por hacer), falta: \n- Calendario "de verdad" bajo la columna "Próximos eventos, que indique todo el cronograma del año, además de que debajo invite a enviarnos un mail para futuras charlas y permitir el acceso al contenido digital de las charlas (si fuiste, te damos un código y con él accedés a toda la info de la charla a la que asististe, de manera online."\n- Imágen que acompañe a cada post bajo la columna "Mejores posts", dónde también indique vistas y likes.\n- Colaboradores del sitio web (nosotros).\n- Sitios webs amigos.\n- Y un sinfín de etcéteras.');
</script>-->

<?php include_once("plug-in/calendario/calendario.php"); ?>

<?php include_once("sistema/header.php"); ?>

<?php include_once("sistema/superPortada.php"); ?> <!-- Esta super portada podrá configurarse cómo:
- Mostrar último post
- Mostrar mejor post (en relación a los likes que obtenga)
- Tener un HTML personalizado por el administrador -->

<div id="contenido">
 
<?php include_once("sistema/columnas.php"); ?>

</div>

<?php include_once("sistema/sobre-nosotros.php"); ?>

<?php include_once("sistema/contacto.php"); ?>

<?php include_once("sistema/pie.php"); ?>

</body>

</html>