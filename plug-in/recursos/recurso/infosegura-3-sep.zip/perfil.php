<!doctype html>
<html lang="es">

 <head>
 	<?php include_once("sistema/informacion.php"); ?>
 	<title><?php echo $nombreDelSitio; ?> | Mi perfil</title>
 	<?php include_once("sistema/header-html.php"); ?> <!-- Para insertar estilos CSS -->
 	<meta charset="UTF-8" />
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 </head>
 
<body>
<?php
/* Importa las credenciales del usuario en caso de que se haya iniciado sesión, así el header puede determinar
	si crear otras listas específicas para los usuarios logueados o no */
if( (isset($_COOKIE["emailCookie"])) && (isset($_COOKIE["contrasenaCookie"])) ) {
	 $rutaUsuario = "usuario/".strip_tags(htmlspecialchars($_COOKIE["emailCookie"]));
	 if(file_exists($rutaUsuario)) {
	   include_once($rutaUsuario."/contrasena-token.php");
	   if(($_COOKIE["contrasenaCookie"]) === $contrasenaTokenUsuario) {
	   	//echo "La contrasenaSaneada es igual a contrasenaUsuario y la cookie MD5 es igual al token";
	   	include_once($rutaUsuario."/credenciales.php");
 		include_once($rutaUsuario."/opciones-de-perfil.php");
 		include_once($rutaUsuario."/configuracion.php");
 		include_once("sistema/header.php");
	 
?>
<!-- Acá metemos toda la página del perfil -->

<div id="portada" style="background-image:url(<?php echo $portadaUsuario; ?>);">
	<div id="avatar" style="background-image:url(<?php echo $avatarUsuario; ?>);"></div>
</div>


<div id="contenido">
 <h1>Bienvenido, <?php echo $_COOKIE['emailCookie']; ?>.</h1>
 <h5>Perfil privado | <a href="sistema/logout.php">Cerrar sesión</a></h5>
 <div id="navDeUsuario">
	<ul>
	 <li><a href="#opcionesDePerfil">Opciones de perfil</a></li>
	 <li><a href="#configuracion">Configuración</a></li>
	</ul>
 </div>
 	<!-- Opciones de perfil -->
 	<div id="opcionesDePerfil">
 		<div id="cerrar"><a href="#navDeUsuario">X</a></div>
 		<div id="titulo">Opciones de perfil</div>
 	<p>¡Pegá el link de tu avatar!</p>
 	<form action="sistema/opciones-de-perfil.php" method="post">
 	 <input type="text" name="avatar" placeholder="Dirección URL de tu imágen de perfil" />
 	 <p>Procurá que la portada sea de al menos 1280x720p</p>
 	 <input type="text" name="portada" placeholder="Dirección URL de tu portada" />
 	 <p>¿Querés hacer público tu perfil? <input type="checkbox" name="publico" value="true" /> </p>
 	 <input type="submit" name="upload" value="Actualizar" />
 	</form>
 	</div>
 	
 	<!-- Configuración -->
 	<div id="configuracion">
 		<div id="cerrar"><a href="#navDeUsuario">X</a></div>
 		<div id="titulo">Configuración del perfil</div>
 	<h3>Notificaciones</h3>
 	<form action="sistema/configuracio-de-perfil.php" method="post">
 	 <select name="notifEMail">
 	  <option>No notificar por ningún medio</option>
 	  <option>Notificar acá la web</option>
 	  <option>Notificar por email y en la web</option>
 	  <option>Notificar por todos los medios</option>
 	 </select>
 	 <select name="tiempo">
 	  <option>Notificar cuándo sea necesario</option>
 	  <option>Notificar periódicamente</option>
 	  <option>Notificar cada 3 días</option>
 	  <option>Notificar semanalmente</option>
 	 </select>
 	</form>
 	</div>
 			 <!-- -->
 			 <div id="puntosUsuario"><h1>Puntos canjeables</h1>
 			  <p>¡Felicidades! Tenés 92 puntos acumulados. Ya podés acceder de manera gratuita a:</p>
 			  <ul>
 			  	<li>Curso de ponis flotantes</li>
 			  	<li>Sniffing con Tom y Jerry</li>
 			  </ul>
 			 </div>

 			 <div id="asistenciasUsuario"><h1>Charlas a las que asististe</h1>
 			  <p>Asististe a la <strong>Charla de conscientización sobre el Grooming</strong> y
 			  <strong>Algo más que una introducción a seguridad informática</strong>.</p>
 			 </div>

 			 <div id="postsCreados"><h1>Tus posts</h1><ul>
 			  <?php include_once($rutaUsuario."/mis-posts.php"); ?>
 			 </ul></div>
 			</div>

<?php
	  }
	 }
// Acá entra sólo si las cookies no fueron seteadas.
} else {
	echo "<div id='contenido'><p>Las cookies no fueron seteadas. <a href='ingresar.php'>Iniciar sesión</a></p></div>";
}
?>
</body>
</html>