<!doctype html>
<html lang="es">

 <head>
   <title>Configuración | Recursos</title>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
 </head>
 
<body>
<?php
if(isset($_FILES['recurso'])){
      $errors= array();
      $file_name = $_FILES['recurso']['name'];
      $file_size =$_FILES['recurso']['size'];
      $file_tmp =$_FILES['recurso']['tmp_name'];
      $file_type=$_FILES['recurso']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['recurso']['name'])));
      
      $expensions= array("zip","ZIP", "rar", "RAR");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="Esta extensión no está permitida, debe ser en formato zip (archivo comprimido)";
      }
      
      if($file_size > 4194304){
         $errors[]='El archivo debe ser menor a 4MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"recurso/".$file_name);
         echo "¡El recurso se subió con éxito!";
      }else{
         print_r($errors);
      }
?>
   <ul>
      <li>Sent file: <?php echo $_FILES['recurso']['name'];  ?></li>
      <li>File size: <?php echo $_FILES['recurso']['size'];  ?></li>
      <li>File type: <?php echo $_FILES['recurso']['type'];  ?></li>
   </ul>
<?php } else {
   echo "No se eligió ningún archivo .zip para subir.";
}
?>
</body>
</html>