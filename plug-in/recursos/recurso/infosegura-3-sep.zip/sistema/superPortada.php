<a href="#"><div id="superPortada">
	<div class="titulo">La big data: ¿cómo manejan nuestros datos?</div>
	<div class="sinopsis">El negocio detrás de la nube "gratis"</div>
</div></a>