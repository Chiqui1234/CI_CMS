<?php
$estadoRecursos=true;
$nombreRecursos="Recursos";
$descripcionRecursos="Creá contenido que sea desbloqueable por el usuario previa insersión de clave.";
$versionRecursos="v1.0";
$autorRecursos="Santiago Gimenez";
$linkRecursos="#";
?>