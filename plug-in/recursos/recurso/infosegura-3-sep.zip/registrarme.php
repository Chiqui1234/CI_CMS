<?php include_once("sistema/informacion.php"); ?>
<!doctype html>
<html lang="es">

 <head>
 	<title><?php echo $nombreDelSitio; ?> | Registrarme</title>
 	<?php include_once("sistema/header-html.php"); ?> <!-- Para insertar estilos CSS -->
 	<meta charset="UTF-8" />
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 </head>
 
<body>
<?php include_once("sistema/header.php"); ?>
<!-- Recordemos que los permisos se escriben como:
PropietarioGrupoOtros y tenemos que sumar estos valores según querramos:
    Lectura: 4
    Escritura: 2
    Ejecución: 1
Por lo que si le queremos aplicar permisos de
lectura y escritura a todos (usuario propietario, grupo y usuario), sería 666 porque 
Lectura+Escritura, es decir, 4+2, resulta en 6). -->
<div id="contenido" style="margin-top: 62px;">
 <form action="registrar-usuario.php" method="post">
	<input type="text" name="email" placeholder="Tu email" />
	<input type="password" name="contrasena" placeholder="Tu contraseña" />
	<input type="password" name="contrasenaRepetida" placeholder="Repetí tu contraseña" />
	<input type="submit" name="registro" value="Registrarte en infosegura" />
 </form>
 <p>Si olvidaste tu contraseña, <a href="recuperar-contrasena.php">recuperala acá</a>.</p>
</div>
</body>
</html>