<?php
 
 $emailSaneado = strip_tags(htmlspecialchars($_REQUEST["email"]));
 $contrasenaSaneada = strip_tags(htmlspecialchars($_REQUEST["contrasena"]));
 $contrasenaToken=md5($contrasenaSaneada); // Contraseña codificada
 $contrasenaTokenAEscribir = '<?php $contrasenaTokenUsuario=md5("'.$contrasenaSaneada.'"); ?>'; // Contraseña codificada, dentro de código PHP y encapsulado en una variable para poder incluirlo en todas las páginas y así verificar el login
 $rutaUsuario = "../usuario/".$emailSaneado;

if((isset($emailSaneado)) && (isset($contrasenaSaneada))) {
	 	if(file_exists("../usuario/".$emailSaneado)) {
	 	include_once($rutaUsuario."/credenciales.php");

	 		if(file_exists("../usuario/".$emailSaneado."/contrasena-token.php")) {
	 			include_once("../usuario/".$emailSaneado."/contrasena-token.php");
	 		} else {
	 			$tokenRuta = fopen($rutaUsuario."/contrasena-token.php", "w");
 			 	fwrite($tokenRuta, $contrasenaTokenAEscribir);
 			 	fclose($tokenRuta);
 			 	include_once("../usuario/".$emailSaneado."/contrasena-token.php");
	 		}

	 		if( ($contrasenaSaneada === $contrasenaUsuario) && ($contrasenaTokenUsuario === $contrasenaToken) ) {
	 	 	 setcookie("emailCookie", strip_tags(htmlspecialchars($_REQUEST["email"])), time()+3600*24, '/');
 			 setcookie("contrasenaCookie", $contrasenaToken, time()+3600*24, '/');
 			} else {
 				echo '<div id="contenido">Las contraseñas no coinciden</div>';
 			}
 		}
}
?>

<!doctype html>
<html lang="es">

 <head>
 	<?php include_once("informacion-sub.php"); ?>
 	<title><?php echo $nombreDelSitio; ?> | Ingresar</title>
 	<?php include_once("header-html-sub.php"); ?> <!-- Para insertar estilos CSS -->
 	<meta charset="UTF-8" />
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 	<meta http-equiv="refresh" content="1; url=../perfil.php" />
 </head>
 
<body>
<div id="contenido">
<?php
if((isset($emailSaneado)) && (isset($contrasenaSaneada))) {
 if(file_exists($rutaUsuario)) {
	// Acá entra si la contraseña guardada en la cookie es igual a la introducida por el usuario
	if( ($contrasenaSaneada === $contrasenaUsuario) && ($contrasenaTokenUsuario === $contrasenaToken) ) {
	 echo "<br /><p>¡Bienvenido ".$emailSaneado."!</p>";
 	 echo "<p>Hash: <strong>".$contrasenaToken."</strong></p>";
 	 echo "<p>Si tu navegador no te redirige en unos pocos segundos, <a href='../perfil.php'>hacé clic acá</a>.</p>";
	} else {
		echo "La contraseña es incorrecta.";
	} 
 } else {
	echo "El usuario no existe;";
	}
}
?>
</div>
</body>
</html>