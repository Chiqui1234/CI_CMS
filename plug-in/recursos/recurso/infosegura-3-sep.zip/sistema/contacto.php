<div id="contacto">

	<div id="contenido">
	 <div class="email"></div>
	 <div class="tituloSector">Contactanos</div>
	 <div id="reCentrado"><form action="contacto.php" method="post">
		<input type="text" placeholder="Tu nombre completo" name="nombre" />
		<input type="text" placeholder="La institución que representás" name="institucion" />
		<textarea name="texto"></textarea>
		<input type="submit" value="Enviar e-mail" />
	 </form></div>
	</div>

</div>